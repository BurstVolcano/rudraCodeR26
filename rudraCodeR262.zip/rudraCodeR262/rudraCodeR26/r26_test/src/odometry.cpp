#include "odometry.h"
#include <cmath>
#include <vector>

using namespace std;

Odometry::Odometry(double wheel_radius, double rpm)
    : radius(wheel_radius), rpm(rpm) {
  double rps = rpm / 60.0;
  linear_vel = 2 * M_PI * radius * rps;
}

double Odometry::distance(int x1, int y1, int x2, int y2) {
  return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

double Odometry::angle(int x1, int y1, int x2, int y2) {
  return atan2(y2 - y1, x2 - x1) * 180.0 / M_PI;
}

MotionCommand Odometry::computeCommands(vector<pair<int, int>> &path) {
  MotionCommand res = {0.0, 0.0};

  if (path.size() < 2) {
    return res;
  }

  double total_distance = 0.0;
  double total_angle_traversed = 0.0;

  for (size_t i = 1; i < path.size(); ++i) {
    int x1 = path[i-1].first;
    int y1 = path[i-1].second;
    int x2 = path[i].first;
    int y2 = path[i].second;

    double segment_distance = distance(x1, y1, x2, y2);
    total_distance += segment_distance;

    double heading = angle(x1, y1, x2, y2);
    total_angle_traversed += abs(heading);
  }

  double total_time = total_distance / linear_vel;

  res.time_sec = total_time;
  res.angle_deg = total_angle_traversed;

  return res;
}