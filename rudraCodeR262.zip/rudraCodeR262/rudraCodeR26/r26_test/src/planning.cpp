#include "planning.h"
#include <algorithm>
#include <cmath>
#include <queue>
#include <vector>

using namespace std;

struct Node {
  int x, y;
  double g, h, f;
  int parent_x, parent_y;

  Node() : x(0), y(0), g(0), h(0), f(0), parent_x(-1), parent_y(-1) {}
  Node(int x, int y) : x(x), y(y), g(0), h(0), f(0), parent_x(-1), parent_y(-1) {}
};

struct Compare {
  bool operator()(const Node& a, const Node& b) {
    return a.f > b.f;
  }
};

Planner::Planner(const vector<vector<bool>> &grid) : grid(grid) {
  rows = grid.size();
  cols = grid[0].size();
}

bool Planner::isvalid(int x, int y) const {
  return (x >= 0 && x < rows && y >= 0 && y < cols && !grid[x][y]);
}

double Planner::heuristic(int x1, int y1, int x2, int y2) const {
  return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}

vector<pair<int, int>> Planner::pathplanning(pair<int, int> start, pair<int, int> goal) {
  vector<pair<int, int>> path;

  if (!isvalid(start.first, start.second) || !isvalid(goal.first, goal.second)) {
    return path;
  }

  if (start.first == goal.first && start.second == goal.second) {
    path.push_back(start);
    return path;
  }

  priority_queue<Node, vector<Node>, Compare> openSet;
  vector<vector<bool>> closedSet(rows, vector<bool>(cols, false));
  vector<vector<Node>> nodeMap(rows, vector<Node>(cols));

  for (int i = 0; i < rows; ++i) {
    for (int j = 0; j < cols; ++j) {
      nodeMap[i][j] = Node(i, j);
    }
  }

  Node startNode(start.first, start.second);
  startNode.g = 0;
  startNode.h = heuristic(start.first, start.second, goal.first, goal.second);
  startNode.f = startNode.g + startNode.h;

  openSet.push(startNode);
  nodeMap[start.first][start.second] = startNode;

  int dx[] = {-1, 1, 0, 0, -1, -1, 1, 1};
  int dy[] = {0, 0, 1, -1, 1, -1, 1, -1};
  double cost[] = {1, 1, 1, 1, 1.414, 1.414, 1.414, 1.414};

  while (!openSet.empty()) {
    Node current = openSet.top();
    openSet.pop();

    closedSet[current.x][current.y] = true;

    if (current.x == goal.first && current.y == goal.second) {
      Node* node = &nodeMap[goal.first][goal.second];
      while (node->parent_x != -1 && node->parent_y != -1) {
        path.push_back({node->x, node->y});
        node = &nodeMap[node->parent_x][node->parent_y];
      }
      path.push_back({start.first, start.second});
      reverse(path.begin(), path.end());
      return path;
    }

    for (int i = 0; i < 8; ++i) {
      int newX = current.x + dx[i];
      int newY = current.y + dy[i];

      if (!isvalid(newX, newY) || closedSet[newX][newY]) {
        continue;
      }

      double tentativeG = current.g + cost[i];
      Node& neighbor = nodeMap[newX][newY];

      if (tentativeG < neighbor.g || neighbor.g == 0) {
        neighbor.g = tentativeG;
        neighbor.h = heuristic(newX, newY, goal.first, goal.second);
        neighbor.f = neighbor.g + neighbor.h;
        neighbor.parent_x = current.x;
        neighbor.parent_y = current.y;

        openSet.push(neighbor);
      }
    }
  }

  return path;
}